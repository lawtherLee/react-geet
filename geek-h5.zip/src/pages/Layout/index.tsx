import React from 'react'

const Layout = () => {
  return <div className="layout">布局页面</div>
}

export default Layout
